# Histogram
hist(autos$mpgCiudad,
  xlab = "Millas por galon (MPG)", ylab = "Frecuencia", main = "")
