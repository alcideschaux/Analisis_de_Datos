# Barplot
barplot(table(autos$trenManejo), xlab = "Tren de manejo", ylab = "Frecuencia")
