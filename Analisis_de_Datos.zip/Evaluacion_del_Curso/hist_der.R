hist(rbeta(10000,2,10), main = "", xlab = "", ylab = "Frecuencia")
