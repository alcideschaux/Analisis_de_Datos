plot(autos$peso, rep(1, nrow(autos)), ylab = "", yaxt = "n", xlab = "Peso (en libras)")
