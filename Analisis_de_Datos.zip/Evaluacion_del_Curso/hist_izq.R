hist(rbeta(10000,5,1), main = "", xlab = "", ylab = "Frecuencia")
