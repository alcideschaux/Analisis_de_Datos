hist(rbeta(10000,5,5), main = "", xlab = "", ylab = "Frecuencia")
