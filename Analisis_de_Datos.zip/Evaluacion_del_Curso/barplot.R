barplot(table(autos$pasajeros), xlab = "No. Pasajeros", ylab = "Frecuencia")
