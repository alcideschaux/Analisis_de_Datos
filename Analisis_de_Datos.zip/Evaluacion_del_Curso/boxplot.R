boxplot(peso ~ trenManejo, data = autos, xlab = "Tren de manejo", ylab = "Peso (en libras)")
